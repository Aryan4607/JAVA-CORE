
class LargestNo {

    public static void main(String[] args) {

        int a = 2;
        int b = 55;
        int c = 22;

        if ((a > b) && (a > c)) {
            System.out.println(a + " greater");

        } else if ((b > a) && (b > c)) {

            System.out.println(b + " greater");

        }

        else if ((c > a) && (c > b)) {

            System.out.println(c + " greater");

        }
    }

}
