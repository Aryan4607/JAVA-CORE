
class Sum {
    public static void main(String[] args) {

        int a = 12;
        int b = 20;
        int sum = 0;

        sum = a + b;

        System.out.println(sum);

    }

}
