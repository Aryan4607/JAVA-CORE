/*(*p*r*t)/100 */

class Task5 {

    public static void main(String[] args) {
        int P = 20000;
        int R = 300;
        int T = 5;
        float si = (P * R * T) / 100;

        System.out.print("Simple interest" + si);

    }

}
