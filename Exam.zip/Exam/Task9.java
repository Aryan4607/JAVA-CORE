
class Task9 {

    public static void main(String[] args) {

        String[] arr = new String[] { "a", "b", "c", "d" };

        for (int i = arr.length - 1; i >= 0; i--) {

            System.out.println(arr[i]);

        }

    }

}
